#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "func.h"
#include <wchar.h>

int errorString(int *m){
	if(scanf("%u", m)==1) {
		return 0;
	}
	else {
		printf("ошибка\n");
		while(getchar()!='\n');
		return 1;
	}
}

void write(struct Cinema*arr, int n){
	if (n <= 0) {
		return;
	}
	FILE *f=fopen("file.txt", "w");
	if(!f) {
		return;
	}
	fprintf(f, "%d\n",n);
	for (int i = 0; i < n; i++) {
		fprintf(f, "%s %f %s\n", arr[i].name, arr[i].price, arr[i].day);
	}
	fclose(f);
}
void read(struct Cinema **arr, int *n){
	FILE *f=fopen("file.txt", "r");
	if(!f)
		return;
	if(fscanf(f,"%d", n)!=1)
		return;
	if(*n<=0)
		return;
	*arr=(struct Cinema *)calloc(*n, sizeof(struct Cinema));
	for (int i=0; i<*n; i++)
		fscanf(f, "%s %f %s", (*arr)[i].name, &(*arr)[i].price, (*arr)[i].day);
	fclose(f);
}
void create(struct Cinema **arr, int *n){
	printf("Введите количество фильмов - ");
	if(errorString(n)) {
		return;
	}
	if (*n <= 0) {
		return;
	}
	*arr=(struct Cinema*)calloc(*n, sizeof(struct Cinema));
	for (int i=0;i<*n;i++){
		printf("Название фильма (без пробелов. можете использовать символ _) - \n");
		scanf("%s",(*arr)[i].name);
		printf("Цена сеанса - \n");
		scanf("%f",&(*arr)[i].price);
		printf("День сеанса (в формате дд.мм.гггг) - \n");
		scanf("%s",(*arr)[i].day);
	}
}
void search(struct Cinema*arr, int *n, int searchS){
	switch(searchS){
		case 1:
			char nameMovie[40];
			printf("Название кино -\n");
			scanf("%40s", nameMovie);
			while(getchar()!='\n');
			for (int i = 0; i < *n; i++){
				if(!strcasecmp(arr[i].name,nameMovie)){
					printf("%s %f %s\n", arr[i].name, arr[i].price, arr[i].day);
				}
				else {
					printf("Не найдено\n");
				}
			}
			break;
		case 2:
			float priceMovie;
                        printf("Цена сеанса -\n");
                  	scanf("%f",&priceMovie);
                        while(getchar()!='\n');
                        for (int i = 0; i < *n; i++){
                                if(priceMovie == arr[i].price){
                                        printf("%s %f %s\n", arr[i].name, arr[i].price, arr[i].day);
                                }
                        }
			break;
		case 3:
			char day[15];
			printf("День сеанса -\n");
			for(int i = 0; i < *n; i++){
				if(!strcmp(arr[i].day, day)){
					printf("%s %f %s\n", arr[i].name, arr[i].price, arr[i].day);
                                }
			}
			break;
		default:
			break;
	}
}
